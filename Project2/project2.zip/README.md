# Project #2

## How to use
Linux:
```shell
pip3 install -r requirements.txt
./run.sh
```
### Test Env

#### Ubuntu
- Ubuntu 20.04.3 LTS
- Python 3.8.10